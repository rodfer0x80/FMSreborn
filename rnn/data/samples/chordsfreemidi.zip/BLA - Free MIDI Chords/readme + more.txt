Thank you for downloading Chords!

Below are some helpful links that will help get you going.

Read our music production blog:
📝 https://blacklotusaudio.com/blog/

Watch our YouTube tutorials:
📺 https://www.youtube.com/c/BlackLotusAudio

Shop our premium soundbanks:
🛒 https://blacklotusaudio.com/shop/